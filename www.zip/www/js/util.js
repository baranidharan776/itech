

function addFooterInnerHTML() {
    $(".footerInnerHTML").html("&copy; " +
        new Date().getFullYear().toString() +
        "&nbsp;&nbsp;&nbsp;&nbsp;iTech Thanjavur");
}
























